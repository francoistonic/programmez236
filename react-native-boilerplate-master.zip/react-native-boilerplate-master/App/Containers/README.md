This directory contains [container components](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0), i.e. React components responsible for the logic of the application.
