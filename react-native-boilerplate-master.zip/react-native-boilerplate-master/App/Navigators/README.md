This directory contains your main Navigator (AppNavigator.js)

You can add nested navigators on this folder if you need it.
